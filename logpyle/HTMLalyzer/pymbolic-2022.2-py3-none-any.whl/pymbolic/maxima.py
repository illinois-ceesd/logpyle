from pymbolic.interop.maxima import *  # noqa

from warnings import warn
warn("pymbolic.maxima is deprecated. Use pymbolic.interop.maxima instead",
        DeprecationWarning)
