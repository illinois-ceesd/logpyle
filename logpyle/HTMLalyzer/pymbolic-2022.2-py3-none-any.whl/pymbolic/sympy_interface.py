from pymbolic.interop.sympy import *  # noqa

from warnings import warn
warn("pymbolic.sympy_interface is deprecated. Use pymbolic.interop.sympy instead",
        DeprecationWarning)
